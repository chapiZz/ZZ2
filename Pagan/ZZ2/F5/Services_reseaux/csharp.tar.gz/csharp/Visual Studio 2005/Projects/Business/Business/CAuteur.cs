using System;
using System.Collections.Generic;
using System.Text;

namespace Business
{
    public class CAuteur  : IAuteur
    {
        private string _nom;
        private string _prenom;

        public string nom
        {
            get
            {
                return _nom;
            }
            set
            {
                _nom = value;
            }
        }

        public string prenom
        {
            get
            {
                return _prenom;
            }
            set
            {
                _prenom = value;
            }
        }

        public override string ToString()
        {
            return prenom + " " + nom;
        }
    }
}

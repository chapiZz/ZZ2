using System;
using System.Collections.Generic;
using System.Text;
using SqlServerMaBiblio;

namespace SqlServerMaBiblio
{
    class Main
    {
        public static void main(string[] args)
        {
            connexionBDD p = new connexionBDD();
            p.load();
            CDAL myDal = new CDAL(CDAL.DALProvider.SQLSERVER, p);
            myDal.getLivres();
            while (true) ;
        }
    }
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MaBiblioIHM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Dimension maDimension = new Dimension();
            maDimension = maDimension.load();
            this.SetDesktopLocation(maDimension.pos_x,maDimension.pos_y);
            this.Size = new Size(maDimension.x, maDimension.y);
        }

        private void userControl2_Load(object sender, EventArgs e)
        {

        }

        private void userControl1_Load(object sender, EventArgs e)
        {

        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.userControl11.update(((LivreNode)((TreeView)sender).SelectedNode).livre);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void aProposDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Dimension maDimension = new Dimension(this.Size.Width,this.Size.Height,this.Location.X,this.Location.Y,this.splitContainer1.Width/this.splitContainer1.SplitterDistance);
            maDimension.save();
 
        }

        private void param�tresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formBDD fbdd = new formBDD();
            fbdd.ShowDialog();
        }
    }
}
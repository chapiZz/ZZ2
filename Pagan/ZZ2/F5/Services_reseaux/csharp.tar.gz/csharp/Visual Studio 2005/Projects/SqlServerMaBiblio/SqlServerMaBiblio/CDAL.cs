using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace SqlServerMaBiblio
{
    public class CDAL : IDAL 
    {
        private IDAL _dal;
        public enum DALProvider
        {
            ORACLE = 1,
            SQLSERVER = 2
        }
        public CDAL(DALProvider provider, connexionBDD p)
        {
            switch(provider)
            {
                /*case DALProvider.ORACLE:
                    _dal = new DALORACLE(p);
                    break;*/
                case DALProvider.SQLSERVER:
                    _dal = new DALSQLSERVER(p);
                    break;
            }
        }
        public DataTable getAuteurs()
        {
            if (_dal != null) return _dal.getAuteurs();
            else return null;
        }
        public DataTable getLivres()
        {
            if (_dal != null) return _dal.getLivres();
            else return null;
        }
        public DataTable getEditeurs()
        {
            if (_dal != null) return _dal.getEditeurs();
            else return null;
        }
      
    }
}

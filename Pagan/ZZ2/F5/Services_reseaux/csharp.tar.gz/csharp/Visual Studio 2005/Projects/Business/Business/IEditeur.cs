using System;
using System.Collections.Generic;
using System.Text;

namespace Business
{
    public interface IEditeur
    {
        string nom
        {
            get;
            set;
        }
        string ToString();
    }
}

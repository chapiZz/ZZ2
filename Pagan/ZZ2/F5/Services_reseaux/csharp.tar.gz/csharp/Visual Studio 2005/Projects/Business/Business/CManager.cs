using System;
using System.Collections.Generic;
using System.Text;

namespace Business
{
    public class CManager : IManager
    {
        public Stack<ILivre> _liste = new Stack<ILivre>();

        public Stack<ILivre> liste
        {
            get
            {
                return _liste;
            }

            set
            {
                _liste = value;
            }
        }
    }
}

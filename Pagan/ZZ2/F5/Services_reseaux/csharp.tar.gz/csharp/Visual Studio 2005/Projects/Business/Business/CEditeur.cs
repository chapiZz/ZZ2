using System;
using System.Collections.Generic;
using System.Text;

namespace Business
{
    public class CEditeur : IEditeur
    {
        private string _nom;

        public string nom
        {
            get 
            {
                return _nom;
            }

            set 
            { 
                _nom = value;
            }
        }
        public override string ToString()
        {
            return nom;
        }
    }
}

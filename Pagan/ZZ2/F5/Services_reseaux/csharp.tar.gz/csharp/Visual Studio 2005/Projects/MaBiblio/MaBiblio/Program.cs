using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using Business;

namespace MaBiblio
{
    class Program
    {
        static void Main(string[] args)
        {
            IManager manager = new CManager();

            manager.liste.Push(new CLivre("Jesewski", "Enguerrand", "Bretagne Editions", "Ma vie en bretagne", "autobiographie", 10.99f, "16/01/2010"));
            manager.liste.Push(new CLivre("Jesewski", "Enguerrand", "Bretagne Editions", "Ma copine la bibine", "enfant", 11.99f, "16/01/2009"));
            
            foreach(ILivre l in manager.liste)
                Console.Out.WriteLine(l+"\n");
        }
    }
}

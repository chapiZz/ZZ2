﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Business;

namespace MaBiblioIHM
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IManager manager = new CManager();
            manager.liste.Push(new CLivre("Jesewski", "Enguerrand", "Bretagne Editions", "Ma vie en bretagne", "autobiographie", 10.99f, "16/01/2010"));
            manager.liste.Push(new CLivre("Jesewski", "Enguerrand", "Bretagne Editions", "Ma copine la bibine", "enfant", 11.99f, "16/01/2009"));
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(manager));
        }
    }
}
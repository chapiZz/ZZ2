using System;
using System.Windows.Forms;
using Business;

/// <summary>
/// Summary description for Class1
/// </summary>
public class LivreNode : TreeNode
{
    public ILivre livre = null;
    
	public LivreNode(ILivre livre)
	{
        this.livre = livre;
        this.Text = livre.ToString();
	}
}

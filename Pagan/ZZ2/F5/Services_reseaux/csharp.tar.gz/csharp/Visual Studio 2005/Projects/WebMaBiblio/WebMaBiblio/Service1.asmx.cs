﻿using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace WebMaBiblio
{
    /// <summary>
    /// Description résumée de Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    public class Service1 : System.Web.Services.WebService
    {
        [WebMethod]
        public bool creditCardValidate(string cardNumber, DateTime expDate)
        {
            if (expDate >= DateTime.Today)
            {
                int total = 0;int temp = 0;
                char[] ccDigits = cardNumber.ToCharArray();
                for (int i = 0; i < cardNumber.Length;  i++)
                {
                    if (((i + 1) % 2) == 0) total += 
                        int.Parse(ccDigits[i].ToString());
                    else
                    {
                        temp = int.Parse(ccDigits[i].ToString()) * 2;
                        if (temp > 9)
                        {
                            temp = (int)temp - 9;
                        }
                        total += temp;
                    }
                }
                if ((total % 10) == 0) return true;
                else return false;
            }
            else
            {
                return false;
            }
        }

        [WebMethod]
        public double currencyConvert(float somme, net.webservicex.www.Currency devise)
        {
            double d = 0;
            if (devise.Equals(net.webservicex.www.Currency.USD)
                || devise.Equals(net.webservicex.www.Currency.GBP)
                || devise.Equals(net.webservicex.www.Currency.EUR))
            {
                net.webservicex.www.CurrencyConvertor c = new net.webservicex.www.CurrencyConvertor();
                d = c.ConversionRate(net.webservicex.www.Currency.EUR, devise);
            }
            return Math.Round(somme * d, 2);
        }


        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
    }
}

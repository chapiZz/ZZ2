using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace SqlServerMaBiblio
{
    public class DALSQLSERVER : IDAL
    {
        connexionBDD p;
        string _chaineConnexion;
        SqlConnection _sqlConnexion;
        public DALSQLSERVER(connexionBDD p)
        {
            this.p = p;
        }
        public void Connexion()
        {
            _chaineConnexion = string.Format("Data Source={1}; User ID={2}; Password={3}; Initial Catalog={0}", p.bdd, p.serveur, p.login, p.mdp);
            _sqlConnexion = new SqlConnection(_chaineConnexion);
            _sqlConnexion.Open();
        }
        public DataTable Select(string strRequete)
        {
            if (_sqlConnexion != null)
            {
                DataTable dt = new DataTable();
                SqlTransaction myTrans = _sqlConnexion.BeginTransaction();
                SqlCommand sqlCommande = new SqlCommand(strRequete, _sqlConnexion, myTrans);
                SqlDataAdapter sqlAdapte = new SqlDataAdapter(sqlCommande);
                try
                {
                    sqlAdapte.Fill(dt);
                    myTrans.Commit();
                    return dt;
                }
                catch
                {
                    myTrans.Rollback();
                    return null;
                }
            }
            return null;
        }
        
        public DataTable getAuteurs()
        {
            return null; ;
        }
        public DataTable getLivres()
        {
            DataTable table = Select("SELECT * FROM BOOKS;");
            DataView v = new DataView(table);
            for (int i = 0; i < v.Count; i++)
            {
                DataRow row = v[i].Row;
                Console.WriteLine("{0}", row["TITLE"]);
            }
            return table;
        }
        public DataTable getEditeurs()
        {
            return null;
        }
        

    }
}

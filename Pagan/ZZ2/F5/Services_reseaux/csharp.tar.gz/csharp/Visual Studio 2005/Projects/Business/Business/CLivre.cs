using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace Business
{
    public class CLivre : ILivre
    {
        //enum genre { Policier, Roman, SF };

        private string _titre;
        private string _datePublication;
        private ArrayList _auteurs;
        private IEditeur _editeur;
        private float _prix;
        private string _genre;

        public CLivre(string nomAuteur, string prenomAuteur, string nomEditeur, string titreLivre, string genreLivre, float prixLivre, string dateLivre)
        {
            ArrayList Liste1 = new ArrayList(); 

            IAuteur Auteur1 = new CAuteur();
            Auteur1.nom = nomAuteur;
            Auteur1.prenom = prenomAuteur;

            IEditeur Editeur1 = new CEditeur();
            Editeur1.nom = nomEditeur;

            _titre = titreLivre;
            _genre = genreLivre;
            Liste1.Add(Auteur1);
            _auteurs = Liste1;
            _editeur = Editeur1;
            _prix = prixLivre;
            _datePublication = dateLivre;
        }

        public string titre
        {
            get
            {
                return _titre;
            }

            set
            {
                _titre = value;
            }
        }
        public string datePublication
        {
            get
            {
                return _datePublication;
            }

            set
            {
                _datePublication = value;
            }
        }
        public ArrayList auteurs
        {
            get
            {
                return _auteurs;
            }

            set
            {
                _auteurs = value;
            }
        }
        public IEditeur editeur
        {
            get
            {
                return _editeur;
            }

            set
            {
                _editeur = value;
            }
        }
        public string genre
        {
            get
            {
                return _genre;
            }

            set
            {
                _genre = value;
            }
        }
        public float prix
        {
            get
            {
                return _prix;
            }

            set
            {
                _prix = value;
            }
        }
        public override String ToString()
        {
            string livre = _titre + " (";
            foreach (IAuteur a in _auteurs)
                livre += a + " ";
            livre += ") [";
            livre += _editeur + ", ";
            livre += _datePublication + ", ";            
            livre += _genre + "]";
            //livre += _prix + "\";
            return livre;
        }
    }
}

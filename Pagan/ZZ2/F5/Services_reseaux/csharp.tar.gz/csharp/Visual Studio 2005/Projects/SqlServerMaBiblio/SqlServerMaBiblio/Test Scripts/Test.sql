-- Exemples de requ�tes qui utilisent diff�rents objets SQL impl�ment�s par cet assembly

-----------------------------------------------------------------------------------------
-- Proc�dure stock�e
-----------------------------------------------------------------------------------------
-- exec StoredProcedureName


-----------------------------------------------------------------------------------------
-- Fonctions d�finies par l'utilisateur
-----------------------------------------------------------------------------------------
-- select dbo.FunctionName()


-----------------------------------------------------------------------------------------
-- Type d�fini par l'utilisateur.
-----------------------------------------------------------------------------------------
-- CREATE TABLE test_table (col1 UserType)
-- go
--
-- INSERT INTO test_table VALUES (convert(uri, 'Instantiation String 1'))
-- INSERT INTO test_table VALUES (convert(uri, 'Instantiation String 2'))
-- INSERT INTO test_table VALUES (convert(uri, 'Instantiation String 3'))
--
-- select col1::method1() from test_table



-----------------------------------------------------------------------------------------
-- Type d�fini par l'utilisateur.
-----------------------------------------------------------------------------------------
-- select dbo.AggregateName(Column1) from Table1


select * FROM BOOKS;

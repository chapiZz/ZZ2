using System;
using System.Collections.Generic;
using System.Text;

namespace Business
{
    public interface IAuteur
    {
        string nom
        {
            get;
            set;
        }

        string prenom
        {
            get;
            set;
        }

        string ToString();
    }
}

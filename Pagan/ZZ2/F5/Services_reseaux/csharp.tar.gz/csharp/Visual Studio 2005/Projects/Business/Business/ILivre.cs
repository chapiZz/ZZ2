using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace Business
{
    public interface ILivre
    {
        string titre
        {
            get;
            set;
        }
        string datePublication
        {
            get;
            set;
        }
        ArrayList auteurs
        {
            get;
            set;
        }
        IEditeur editeur
        {
            get;
            set;
        }
        string genre
        {
            get;
            set;
        }
        float prix
        {
            get;
            set;
        }
        string ToString();
    }
}

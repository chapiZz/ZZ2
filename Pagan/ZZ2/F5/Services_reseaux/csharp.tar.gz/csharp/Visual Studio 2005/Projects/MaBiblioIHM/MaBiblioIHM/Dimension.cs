using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace MaBiblioIHM
{
    [SerializableAttribute]
    public class Dimension
    {
        public int x, y;
        public int pos_x, pos_y;
        public float rapport;

        public Dimension(int x, int y, int pos_x, int pos_y, float rapport)
        {
            this.x = x;
            this.y = y;
            this.pos_x = pos_x;
            this.pos_y = pos_y;
            this.rapport = rapport;
        }
        public Dimension() { }
        public void save()
        {
            StreamWriter stream = new StreamWriter(@"c:\easyXML.net");
            XmlSerializer serializer = new XmlSerializer(typeof(Dimension));
            serializer.Serialize(stream, this);
            stream.Close();
        }
        public Dimension load()
        {
            Dimension maDimension = new Dimension();
            XmlSerializer deserializer = new XmlSerializer(typeof(Dimension));
            StreamReader stream = new StreamReader(@"c:\easyXML.net");
            maDimension = (Dimension)deserializer.Deserialize(stream);
            stream.Close();
            return maDimension;
        }
    }
}

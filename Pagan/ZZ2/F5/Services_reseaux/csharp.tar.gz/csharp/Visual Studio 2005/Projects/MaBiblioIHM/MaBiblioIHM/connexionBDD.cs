using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Security.Cryptography;

namespace MaBiblioIHM
{
    [SerializableAttribute]
    public class connexionBDD
    {
        public String serveur;
        public String bdd;
        public String login;
        public String mdp;

        public connexionBDD() { }
        public connexionBDD(String serveur, String bdd, String login, String mdp)
        {
            this.serveur = serveur;
            this.bdd = bdd;
            this.login = login;
            this.mdp = mdp;
        }

        public string Encrypt(string original, SymmetricAlgorithm sa)
        {
            ICryptoTransform ct; MemoryStream ms; CryptoStream cs;   byte[] byt; 
            ct = sa.CreateEncryptor(sa.Key, sa.IV);
            byt = Encoding.UTF8.GetBytes(original);
            ms = new MemoryStream();
            cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
            cs.Write(byt, 0, byt.Length);
            cs.FlushFinalBlock();
            cs.Close();
            return  Convert.ToBase64String(ms.ToArray());
        }

        public string Decrypt(string crypte, SymmetricAlgorithm sa)
        {
            ICryptoTransform ct; MemoryStream ms; CryptoStream cs; byte[] byt;
            ct = sa.CreateDecryptor(sa.Key, sa.IV);
            byt = Convert.FromBase64String(crypte);
            ms = new MemoryStream();
            cs = new CryptoStream(ms, ct, CryptoStreamMode.Write);
            cs.Write(byt, 0, byt.Length);
            cs.FlushFinalBlock();
            cs.Close();
            return Encoding.UTF8.GetString(ms.ToArray());
        }

        public connexionBDD load()
        {
            connexionBDD maBDD = new connexionBDD();
            XmlSerializer deserializer = new XmlSerializer(typeof(connexionBDD));
            try
            {
                StreamReader stream = new StreamReader(@"c:\easyXML_bdd.net");
                maBDD = (connexionBDD)deserializer.Deserialize(stream);
                stream.Close();
                TripleDESCryptoServiceProvider d = new TripleDESCryptoServiceProvider();
                d.GenerateIV();
                d.GenerateKey();
                maBDD.mdp = Decrypt(maBDD.mdp, d);
            }
            catch (Exception e)
            {
                maBDD.serveur = "Server";
                maBDD.bdd = "Database";
                maBDD.login = "Login";
                maBDD.mdp = "Password";
            }
            return maBDD;
        }
        public void save()
        {
            TripleDESCryptoServiceProvider d = new TripleDESCryptoServiceProvider();
            d.GenerateIV();
            d.GenerateKey();
            mdp = Encrypt(mdp, d); 
            StreamWriter stream = new StreamWriter(@"c:\easyXML_bdd.net");
            XmlSerializer serializer = new XmlSerializer(typeof(connexionBDD));
            serializer.Serialize(stream, this);
            stream.Close();
        }

    }
}
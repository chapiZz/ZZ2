using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MaBiblioIHM
{
    public partial class formBDD : Form
    {
        public connexionBDD paramBDD;
        public formBDD()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void formBDD_Load(object sender, EventArgs e)
        {
            paramBDD = new connexionBDD();
            paramBDD = paramBDD.load();
            textBox1.Text = paramBDD.serveur;
            textBox2.Text = paramBDD.bdd;
            textBox3.Text = paramBDD.login;
            textBox4.Text = paramBDD.mdp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            paramBDD.serveur = textBox1.Text;
            paramBDD.bdd = textBox2.Text;
            paramBDD.login = textBox3.Text;
            paramBDD.mdp = textBox4.Text;
            paramBDD.save();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = paramBDD.serveur;
            textBox2.Text = paramBDD.bdd;
            textBox3.Text = paramBDD.login;
            textBox4.Text = paramBDD.mdp;
            Close();
        }

        private void formBDD_FormClosed(object sender, FormClosedEventArgs e)
        {
            paramBDD.save();
        }
    }
}
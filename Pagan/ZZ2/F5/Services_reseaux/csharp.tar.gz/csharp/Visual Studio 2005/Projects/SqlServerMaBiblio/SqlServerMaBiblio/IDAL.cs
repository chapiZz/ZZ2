using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace SqlServerMaBiblio
{
    public interface IDAL
    {
        DataTable getLivres();
        DataTable getAuteurs();
        DataTable getEditeurs();
    }

}

/*using System;
using System.Collections.Generic;
using System.Text;

namespace SqlServerMaBiblio
{
    public class DataProvider
    {
        private static DataProvider _dalProvider;
        private static readonly object padlock = new object();
        public static DataProvider Instance
        {
            get
            {
                if (_dalProvider == null)
                {
                    lock (padlock)
                    {
                        if (_dalProvider == null)
                        {
                            _dalProvider = new DataProvider();
                        }
                    }
                }
                return _dalProvider;
            }
        }
    }
}
*/